
<?php /*@extends('layouts.app')

@section('content')
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Vendre un produit</h1>
                </div>
               {{-- <div class="col-sm-6">
                    <a class="btn btn-primary float-right"
                       href="{{ route('acheters.create') }}">
                        Add New
                    </a>
                </div>--}}
            </div>
        </div>
    </section>

    <div class="content px-3">

        @include('flash::message')

        <div class="clearfix"></div>

        <div class="card">

            <div class="card-body p-0">
                <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet" />
                <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>
                <!-- HTML -->
                <form id="product-form">
                    @csrf
                    <div class="p-3" style="display: flex; align-items: center;">

                        <div class="form-group" style="display: flex; flex-direction: column; width: 50%;">
                            <label>Liste des produits </label>
                            <select id="product-select" name="produit_id" class="form-control col-sm-6 select2 w-100" required>
                                <option value="">Sélectionnez un produit</option>
                                @foreach ($produits as $produit)
                                    <option value="{{$produit->id}}" data-price="{{ $produit->prix_public }}" data-qte_final="{{$produit->qte_final}}" data-id="{{$produit->id}}">{{ $produit->libelle }}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="form-group ml-auto">
                            <label for="montant-client">Montant du client :</label>
                            <input type="number" class="form-control" id="montant-client" name="montant-client" required>
                        </div>
                    </div>


                <div class="table-responsive">
                <table class="table" id="product-list">
                    <thead>
                    <tr>

                        <th>Produit</th>
                        <th></th>
                        <th>Prix public (FR CFA)</th>
                        <th>Quantité restante</th>
                        <th>Quantité</th>
                        <th>Montant</th>
                        <th>Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                    </tbody>
                    <tfoot>
                    <tr>
                        <td colspan="3" align="right"><strong>Total:</strong></td>
                        <td><span id="total-amount">0</span></td>
                        <td><span id="quantity-error" class="error" style="display:none; text-align: center; color: red"></span></td>
                        <td><span id="quantity-error-negatif" class="error" style="display:none; text-align: center; color: red"></span></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    </tfoot>
                </table>
                </div>
                    <div style="margin-left: 21px; position: relative; top: -8px;">
                        <button class="btn btn-primary float-left" data-toggle="modal" data-target="#myModal" type="submit">Récapitulatif</button>
                    </div>

                    <!-- Bouton pour ouvrir la fenêtre modale -->
                    <!-- <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal" style="margin-left: 21px; position: relative; top: -8px;">
                        Ouvrir la fenêtre modale
                    </button> -->

                    <button class="btn btn-primary float-left" onclick="window.print()" style="margin-left: 21px; position: relative; top: -8px;">Imprimer</button>

                    <!-- Fenêtre modale -->
                    <div class="modal" id="myModal">
                        <div class="modal-dialog">
                            <div class="modal-content">

                                <!-- Header de la fenêtre modale -->
                                <div class="modal-header">
                                    <h4 class="modal-title">Récapitulatif des produits achetés</h4>
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                </div>

                                <!-- Contenu de la fenêtre modale -->
                                <div class="modal-body">
                                    <p ></p>
                                </div>

                                <!-- Footer de la fenêtre modale -->
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
                                </div>

                            </div>
                        </div>
                    </div>
                </form>
            </div>


            <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
           <script type="text/javascript">
               $('#product-form').load('index.blade.php', function() {

                   // JS
                   $(document).ready(function () {
                       var productCount = 0;
                       var totalAmount = 0;
                       var qte_final = 0;


                       $('#product-select').change(function () {
                           var productId = $(this).val();
                           var productName = $(this).find('option:selected').text();
                           var productPrice = $(this).find('option:selected').data('price');
                           var productQuantityRestante = $(this).find('option:selected').data('qte_final');
                           qte_final = productQuantityRestante;
                           productCount++;

                           var newRow = '<tr id="product-row-' + productCount + '">' +
                               '<td><input type="text" value="' + productName + '" class="form-control prod" name="product[' + productCount + '][name]" placeholder="Nom du produit" id="myInput" disabled> </td>' +
                               '<td><input type="text" value="' + productName + '" class="form-control prod hidden" name="product[' + productCount + '][name]" placeholder="Nom du produit" id="myInput" hidden> </td>' +
                               '<td><input type="text" name="product[' + productCount + '][price]" class="form-control price" value="' + productPrice + '" disabled></td>' +
                               '<td><input type="text"  name="product[' + productCount + '][qte_final]" class="form-control price" value="' + productQuantityRestante + '" disabled></td>' +
                               '<td><input type="number" min="1" max="' + qte_final + '" id="quantite" name="product[' + productCount + '][quantity]" class="form-control quantity" required></td>' +
                               '<td class="amount">0</td>' +
                               '<td><button class="btn btn-danger btn-sm remove-product" data-row-id="' + productCount + '">Supprimer</button></td>' +
                               '</tr>';

                           $('#product-list tbody').append(newRow);
                           $('#recap-product-list tbody').append(newRow);
                          // console.log(productId)
                       });

                       //
                       $(document).on('input', '#quantite', function () {
                        // Récupérer la quantité saisie
                        var quantite_saisie = $(this).val();
                        if (quantite_saisie > 0) {
                            $('#quantity-error-negatif').hide()
                            if (quantite_saisie > qte_final) {
                                $('#quantite').val(qte_final);
                                $('#quantity-error').html('La quantité demandée est supérieure à la quantité en stock.').show();
                                $('#quantite').html('');
                            } else {
                                $('#quantity-error').hide();
                                $('#quantite').html('');
                            }
                        } else {
                            $('#quantity-error-negatif').html('La quantité demandée ne peut pas être négative.').show();
                        }
                    });

                       $(document).on('click', '.remove-product', function () {
                           var rowId = $(this).data('row-id');
                           var rowAmount = $('#product-row-' + rowId + ' .amount').text();
                           totalAmount -= parseInt(rowAmount);
                           $('#product-row-' + rowId).remove();
                           calculateTotal();
                       });

                       $(document).on('input', '.price, .quantity', function () {
                           var row = $(this).closest('tr');
                           var price = row.find('.price').val();
                           var quantity = row.find('.quantity').val();
                           var amount = price * quantity;
                           row.find('.amount').text(amount);
                           calculateProductTotal(row);
                           calculateTotal();
                       });

                       function calculateProductTotal(row) {
                           var price = row.find('.price').val();
                           var quantity = row.find('.quantity').val();
                           var amount = price * quantity;
                           row.find('.amount').text(amount);
                       }

                       function calculateTotal() {
                           totalAmount = 0;
                           $('.amount').each(function () {
                               totalAmount += parseInt($(this).text());
                           });
                           $('#total-amount').text(totalAmount);
                       }

                       $('#product-form').submit(function (event) {
                           event.preventDefault();
                           var formData = $(this).serialize();

                           $.ajax({
                               url: '/sell',
                               type: 'POST',
                               data: formData,
                               success: function (response) {
                                   // Code à exécuter en cas de succès
                                   console.log(response)
                                   ('.quantity').text("");
                               },
                               error: function (xhr, status, error) {
                                   console.log(response.data)
                               }
                           });
                       });
                   });
               });
           </script>
            <script>
                $(document).ready(function() {
                    $('.select2').select2();
                });
            </script>



        </div>
    </div>

@endsection*/?>
@extends('layouts.app')

@section('content')
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Vendre un produit</h1>
                </div>
            </div>
        </div>
    </section>

    <div class="content px-3">
        @include('flash::message')
        <div class="clearfix"></div>
        <div class="card">
            <div class="card-body p-0">
                <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
                <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
                <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet" />
                <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>
                <form id="product-form">
                    @csrf
                    <div class="p-3 d-flex align-items-center">
                        <div class="form-group w-50">
                            <label class="mb-0">Liste des produits</label>
                            <select id="product-select" name="produit_id" class="form-control col-sm-6 select2 w-100" required>
                                <option value="">Sélectionnez un produit</option>
                                @foreach ($produits as $produit)
                                    <option value="{{$produit->id}}" data-price="{{ $produit->prix_public }}" data-qte_final="{{$produit->qte_final}}" data-id="{{$produit->id}}">{{ $produit->libelle }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group ml-auto">
                            <label for="montant-client" class="mb-0">Montant du client :</label>
                            <input type="number" class="form-control" id="montant-client" name="montant-client" required>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table class="table" id="product-list">
                            <thead>
                                <tr>
                                    <th>Produit</th>
                                    <th></th>
                                    <th>Prix public (FR CFA)</th>
                                    <th>Quantité restante</th>
                                    <th>Quantité</th>
                                    <th>Montant</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody></tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="4" align="right"><strong>Total:</strong></td>
                                    <td><span id="total-amount">0</span></td>
                                    <td></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>

                    <div class="d-flex justify-content-start m-3">
                        <button disabled class="btn btn-primary float-left" data-toggle="modal" type="button" id="recap-button">Valider</button>
                    </div>

                    <div class="modal" id="myModal">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h4 class="modal-title">Récapitulatif des produits achetés</h4>
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                </div>
                                <div class="modal-body">
                                    <p id="recap-content"></p>
                                    <p id="total-price"></p>
                                    <p id="rest-to-give"></p>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                                    <button type="submit" class="btn btn-primary">Confirmer</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            $('.select2').select2();

            var productList = [];
            var productCount = 0;

            $('#product-select').on('change', function() {
                var selectedOption = $(this).find(':selected');
                var productId = selectedOption.data('id');
                var productPrice = selectedOption.data('price');
                var qteFinal = selectedOption.data('qte_final');
                var productName = selectedOption.text();

                var index = productList.findIndex(product => product.id === productId);
                if (index === -1) {
                    productList.push({
                        id: productId,
                        price: productPrice,
                        qte_final: qteFinal,
                        qte: 1,
                        name: productName
                    });
                } else {
                    var qte = productList[index].qte;
                    if (qte < qteFinal) {
                        productList[index].qte += 1;
                    } else {
                        toastr.warning('Quantité maximale atteinte pour ce produit !');
                    }
                }
                productCount++;

                renderProductList();
            });

            $(document).on('click', '.delete-product', function() {
                var productId = $(this).data('id');
                var index = productList.findIndex(product => product.id === productId);
                productList.splice(index, 1);
                renderProductList();
            });

            $(document).on('input', '.qte-input', function() {
                var qte = $(this).val();
                var productId = $(this).data('id');
                var index = productList.findIndex(product => product.id === productId);
                productList[index].qte = parseInt(qte);
                renderProductList();
            });

            $('#recap-button').on('click', function() {
                var totalAmount = productList.reduce(function(total, product) {
                        return total + (product.price * product.qte);
                    }, 0);
                var restToGive = parseInt($('#montant-client').val()) - totalAmount;
                if(restToGive < 0)
                {
                    $('#recap-button').attr({
                        'data-target': null
                    });
                    toastr.error("La somme du client ne peut pas achéter les produits du panier");
                    return;
                }
                $('#recap-button').attr({
                    'data-target': "#myModal"
                });
                $('#recap-content').html(renderRecapContent());
            });

            $('#montant-client').on('input', function(){
                canEnableValidateButton();
            });

            $('#product-form').on('submit', function(e) {
                e.preventDefault();

                var montantClient = parseInt($('#montant-client').val());

                var totalAmount = productList.reduce(function(total, product) {
                    return total + (product.price * product.qte);
                }, 0);

                var restToGive = montantClient - totalAmount;

                if (restToGive >= 0) {
                    var formData = $(this).serialize();
                    console.log(formData)
                           $.ajax({
                               url: '/sell',
                               type: 'POST',
                               data: formData,
                               success: function (response) {
                                   // Code à exécuter en cas de succès
                                   toastr.success('Vente effectuée avec succès !');
                               },
                               error: function (xhr, status, error) {
                                   toastr.error('Une erreur est survenue !');
                               }
                           });
                } else {
                    toastr.warning('Le montant donné est insuffisant !');
                }
            });

            function canEnableValidateButton()
            {
                if(productList.length > 0 && parseInt($('#montant-client').val()) > 0)
                {
                    $('#recap-button').attr({
                        disabled: false
                    })
                }
                else
                {
                    $('#recap-button').attr({
                        disabled: true
                    })
                }
            }

            function renderProductList() {
                var tbody = $('#product-list tbody');
                tbody.empty();

                var totalAmount = 0;

                productList.forEach(function(product) {
                    var amount = product.price * product.qte;
                    totalAmount += amount;

                    var tr = $('<tr>');
                    tr.append($('<td>').append($('<input>').attr({
                        type: 'text',
                        class: 'form-control prod',
                        value: product.name,
                        name: 'product[' + productCount + '][name]',
                        placeholder: 'Nom du produit',
                        id: 'myInput',
                        disabled: true
                    })));
                    tr.append($('<td>').append($('<input>').attr({
                        type: 'text',
                        class: 'form-control prod hidden',
                        value: product.name,
                        name: 'product[' + productCount + '][name]',
                        placeholder: 'Nom du produit',
                        id: 'myInput',
                        hidden: true
                    })));
                    tr.append($('<td>').append($('<input>').attr({
                        type: 'text',
                        name: 'product[' + productCount + '][price]',
                        class: 'form-control price',
                        value: product.price,
                        disabled: true
                    })));
                    tr.append($('<td>').append($('<input>').attr({
                        type: 'text',
                        name: 'product[' + productCount + '][qte_final]',
                        class: 'form-control price',
                        value: product.qte_final,
                        disabled: true
                    })));
                    tr.append($('<td>').append($('<input>').attr({
                        type: 'number',
                        name: 'product[' + productCount + '][quantity]',
                        class: 'form-control qte-input',
                        'data-id': product.id,
                        value: product.qte,
                        min: 1,
                        max: product.qte_final
                    })));
                    tr.append($('<td>').text(amount));
                    var deleteButton = $('<button>').attr({
                        type: 'button',
                        class: 'btn btn-danger delete-product',
                        'data-id': product.id
                    }).text('Supprimer');
                    tr.append($('<td>').append(deleteButton));
                    tbody.append(tr);
                });

                $('#total-amount').text('Montant total: ' + totalAmount + ' FR CFA');
                canEnableValidateButton();
            }

            function renderRecapContent() {
            var content = $('<div>');
            var productListDiv = $('<div>').addClass('mb-3');
            var ul = $('<ul>').addClass('list-group');
                var li = $('<li>').addClass('list-group-item d-flex justify-content-between align-items-center active');
                li.append($('<span>').text('Libellé'));
                li.append($('<span>').text('Quantité'));
                li.append($('<span>').text('Montant'));
                ul.append(li);
            productList.forEach(function(product) {
                var amount = product.price * product.qte;
                var li = $('<li>').addClass('list-group-item d-flex justify-content-between align-items-center');
                li.append($('<span>').text(product.name));
                li.append($('<span>').addClass('badge badge-primary badge-pill').text(product.qte));
                li.append($('<span>').addClass('badge badge-success badge-pill').text(amount + ' FR CFA'));
                ul.append(li);
            });
            productListDiv.append(ul);
            content.append(productListDiv);

            var montantClient = parseInt($('#montant-client').val());
            var totalAmount = productList.reduce(function(total, product) {
                return total + (product.price * product.qte);
            }, 0);
            var restToGive = montantClient - totalAmount;

            var totalAmountDiv = $('<div>').addClass('mb-3');
            totalAmountDiv.append($('<h5>').text('Montant total:').addClass('d-inline'));
            totalAmountDiv.append($('<span>').text(totalAmount + ' FR CFA').addClass('float-right'));

            var restToGiveDiv = $('<div>').addClass('mb-3');
            restToGiveDiv.append($('<h5>').text('Reste à donner:').addClass('d-inline'));
            restToGiveDiv.append($('<span>').text(restToGive + ' FR CFA').addClass('float-right'));

            var givenAmountDiv = $('<div>').addClass('mb-3');
            givenAmountDiv.append($('<h5>').text('Montant donné par le client:').addClass('d-inline'));
            givenAmountDiv.append($('<span>').text(montantClient + ' FR CFA').addClass('float-right'));

            content.append(totalAmountDiv);
            content.append(restToGiveDiv);
            content.append(givenAmountDiv);

            return content;
        }
        });
    </script>
@endsection
