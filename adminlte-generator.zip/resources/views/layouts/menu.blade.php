<li class="nav-item">
    <a href="{{ route('categories.index') }}"
       class="nav-link {{ Request::is('categories*') ? 'active' : '' }}">
        <p>Categories</p>
    </a>
</li>


<li class="nav-item">
    <a href="{{ route('lots.index') }}"
       class="nav-link {{ Request::is('lots*') ? 'active' : '' }}">
        <p>Lots</p>
    </a>
</li>


<li class="nav-item">
    <a href="{{ route('produits.index') }}"
       class="nav-link {{ Request::is('produits*') ? 'active' : '' }}">
        <p>Produits</p>
    </a>
</li>


<li class="nav-item">
    <a href="{{ route('acheters.index') }}"
       class="nav-link {{ Request::is('acheters*') ? 'active' : '' }}">
        <p>Vendre produit</p>
    </a>
</li>


<li class="nav-item">
    <a href="/sell-prod-list"
       class="nav-link {{ Request::is('liste*') ? 'active' : '' }}">
        <p>Liste des produits vendus</p>
    </a>
</li>
