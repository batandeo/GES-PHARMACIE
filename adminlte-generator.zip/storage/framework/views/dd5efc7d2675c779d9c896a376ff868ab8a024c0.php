<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Vendre un produit</h1>
                </div>
               
            </div>
        </div>
    </section>

    <div class="content px-3">

        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="clearfix"></div>

        <div class="card">

            <div class="card-body p-0">
                <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet" />
                <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>
                <!-- HTML -->
                <form id="product-form">
                    <?php echo csrf_field(); ?>
                    <div style="display: flex;margin-top: 30px; margin-bottom: 30px;margin-left: 25px;">
                        <label>Liste des produits:</label>
                        <select id="product-select" name="produit_id" class="form-control col-sm-6 select2" style="margin-left: 10px;" required>
                            <option value="">Sélectionnez un produit</option>
                            <?php $__currentLoopData = $produits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($produit->id); ?>" data-price="<?php echo e($produit->prix_public); ?>" data-qte_final="<?php echo e($produit->qte_final); ?>" data-id="<?php echo e($produit->id); ?>"><?php echo e($produit->libelle); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>


                <div class="table-responsive">
                <table class="table" id="product-list">
                    <thead>
                    <tr>

                        <th>Produit</th>
                        <th></th>
                        <th>Prix public (FR CFA)</th>
                        <th>Quantité restante</th>
                        <th>Quantité</th>
                        <th>Montant</th>
                        <th>Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                    </tbody>
                    <tfoot>
                    <tr>
                        <td colspan="3" align="right"><strong>Total:</strong></td>
                        <td><span id="total-amount">0</span></td>
                        <td><span id="quantity-error" class="error" style="display:none; text-align: center; color: red"></span></td>
                        <td><span id="quantity-error-negatif" class="error" style="display:none; text-align: center; color: red"></span></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    </tfoot>
                </table>
                </div>
                    <div style="margin-left: 21px; position: relative; top: -8px;">
                        <button class="btn btn-primary float-left" type="submit">Récapitulatif</button>
                    </div>

                    <!-- Bouton pour ouvrir la fenêtre modale -->
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
                        Ouvrir la fenêtre modale
                    </button>

                    <!-- Fenêtre modale -->
                    <div class="modal" id="myModal">
                        <div class="modal-dialog">
                            <div class="modal-content">

                                <!-- Header de la fenêtre modale -->
                                <div class="modal-header">
                                    <h4 class="modal-title">Récapitulatif des produits achetés</h4>
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                </div>

                                <!-- Contenu de la fenêtre modale -->
                                <div class="modal-body">
                                    <p ></p>
                                </div>

                                <!-- Footer de la fenêtre modale -->
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
                                </div>

                            </div>
                        </div>
                    </div>
                </form>
            </div>


            <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
           <script type="text/javascript">
               $('#product-form').load('index.blade.php', function() {

                   // JS
                   $(document).ready(function () {
                       var productCount = 0;
                       var totalAmount = 0;
                       var qte_final = 0;


                       $('#product-select').change(function () {
                           var productId = $(this).val();
                           var productName = $(this).find('option:selected').text();
                           var productPrice = $(this).find('option:selected').data('price');
                           var productQuantityRestante = $(this).find('option:selected').data('qte_final');
                           qte_final = productQuantityRestante;
                           productCount++;

                           var newRow = '<tr id="product-row-' + productCount + '">' +
                               '<td><input type="text" value="' + productName + '" class="form-control prod" name="product[' + productCount + '][name]" placeholder="Nom du produit" id="myInput" disabled> </td>' +
                               '<td><input type="text" value="' + productName + '" class="form-control prod hidden" name="product[' + productCount + '][name]" placeholder="Nom du produit" id="myInput" hidden> </td>' +
                               '<td><input type="text" name="product[' + productCount + '][price]" class="form-control price" value="' + productPrice + '" disabled></td>' +
                               '<td><input type="text"  name="product[' + productCount + '][qte_final]" class="form-control price" value="' + productQuantityRestante + '" disabled></td>' +
                               '<td><input type="number" id="quantite" name="product[' + productCount + '][quantity]" class="form-control quantity" required></td>' +
                               '<td class="amount">0</td>' +
                               '<td><button class="btn btn-danger btn-sm remove-product" data-row-id="' + productCount + '">Supprimer</button></td>' +
                               '</tr>';

                           $('#product-list tbody').append(newRow);
                           $('#recap-product-list tbody').append(newRow);
                          // console.log(productId)
                       });

                       //
                       $(document).on('change', '#quantite', function () {
                               // Récupérer la quantité saisie
                           var quantite_saisie = $(this).val();
                           if(quantite_saisie > 0){
                               $('#quantity-error-negatif').hide()
                               if (quantite_saisie > qte_final) {
                                   $('#quantite').val(qte_final);
                                   $('#quantity-error').html('La quantité demandée est supérieure à la quantité en stock.').show();
                                   $('#quantite').html('');
                               }else {
                                   $('#quantity-error').hide();
                                   $('#quantite').html('');
                               }
                           }else {
                               $('#quantity-error-negatif').html('La quantité demandée ne peut pas être négative.').show();
                           }

                       });

                       $(document).on('click', '.remove-product', function () {
                           var rowId = $(this).data('row-id');
                           var rowAmount = $('#product-row-' + rowId + ' .amount').text();
                           totalAmount -= parseInt(rowAmount);
                           $('#product-row-' + rowId).remove();
                           calculateTotal();
                       });

                       $(document).on('change', '.price, .quantity', function () {
                           var row = $(this).closest('tr');
                           var price = row.find('.price').val();
                           var quantity = row.find('.quantity').val();
                           var amount = price * quantity;
                           row.find('.amount').text(amount);
                           calculateProductTotal(row);
                           calculateTotal();
                       });

                       function calculateProductTotal(row) {
                           var price = row.find('.price').val();
                           var quantity = row.find('.quantity').val();
                           var amount = price * quantity;
                           row.find('.amount').text(amount);
                       }

                       function calculateTotal() {
                           totalAmount = 0;
                           $('.amount').each(function () {
                               totalAmount += parseInt($(this).text());
                           });
                           $('#total-amount').text(totalAmount);
                       }

                       $('#product-form').submit(function (event) {
                           event.preventDefault();
                           var formData = $(this).serialize();

                           $.ajax({
                               url: '/sell',
                               type: 'POST',
                               data: formData,
                               success: function (response) {
                                   // Code à exécuter en cas de succès
                                   console.log(response)
                                   ('.quantity').text("");
                               },
                               error: function (xhr, status, error) {
                                   console.log(response.data)
                               }
                           });
                       });
                   });
               });
           </script>
            <script>
                $(document).ready(function() {
                    $('.select2').select2();
                });
            </script>



        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Hiss24\Downloads\Telegram Desktop\adminlte-generator\resources\views/acheters/index.blade.php ENDPATH**/ ?>