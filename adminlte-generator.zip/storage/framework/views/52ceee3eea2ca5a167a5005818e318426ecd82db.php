<!-- Libelle Field -->
<div class="col-sm-6">
    <?php echo Form::label('libelle', 'Nom du produit:'); ?>

    <p><?php echo e($produit->libelle); ?></p>
</div>

<!-- Code Field -->
<div class="col-sm-6">
    <?php echo Form::label('code', 'Code:'); ?>

    <p><?php echo e($produit->code); ?></p>
</div>

<!-- Qte Minimal Field -->
<div class="col-sm-6">
    <?php echo Form::label('qte_minimal', 'Quantité Minimal:'); ?>

    <p><?php echo e($produit->qte_minimal); ?></p>
</div>

<!-- Qte Init Field -->
<div class="col-sm-6">
    <?php echo Form::label('qte_init', 'Quantité Initiale:'); ?>

    <p><?php echo e($produit->qte_init); ?></p>
</div>

<!-- Qte Final Field -->
<div class="col-sm-6">
    <?php echo Form::label('qte_final', 'Quantité Restante:'); ?>

    <p><?php echo e($produit->qte_final); ?></p>
</div>

<!-- Prix Session Field -->
<div class="col-sm-6">
    <?php echo Form::label('prix_session', 'Prix Session:'); ?>

    <p><?php echo e($produit->prix_session); ?></p>
</div>

<!-- Prix Public Field -->
<div class="col-sm-6">
    <?php echo Form::label('prix_public', 'Prix Public:'); ?>

    <p><?php echo e($produit->prix_public); ?></p>
</div>

<!-- Qte Sortie Field -->
<div class="col-sm-6">
    <?php echo Form::label('qte_sortie', 'Quantité Vendue:'); ?>

    <p><?php echo e($produit->qte_sortie); ?></p>
</div>

<!-- Date Peremp Field -->
<div class="col-sm-6">
    <?php echo Form::label('date_peremp', 'Date Péremption:'); ?>

    <p><?php echo e($produit->date_peremp); ?></p>
</div>


<!-- Lot Id Field -->
<div class="col-sm-6">
    <?php echo Form::label('lot_id', 'Lot:'); ?>

    <p><?php echo e(optional($produit->lot)->numero); ?></p>
</div>

<!-- Categorie Id Field -->
<div class="col-sm-6">
    <?php echo Form::label('categorie_id', 'Categorie:'); ?>

    <p><?php echo e(optional($produit->categorie)->libelle); ?></p>
</div>

<!-- Created At Field -->
<div class="col-sm-6">
    <?php echo Form::label('created_at', 'Date enregistrée:'); ?>

    <p><?php echo e($produit->created_at); ?></p>
</div>

<!-- Updated At Field -->


<?php /**PATH C:\Users\Hiss24\Downloads\Telegram Desktop\adminlte-generator\resources\views/produits/show_fields.blade.php ENDPATH**/ ?>