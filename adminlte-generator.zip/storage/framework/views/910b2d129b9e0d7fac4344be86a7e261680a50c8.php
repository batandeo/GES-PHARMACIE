<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-12">
                    <h1>Create Produit</h1>
                </div>
            </div>
        </div>
    </section>

    <div class="content px-3">

        <?php echo $__env->make('adminlte-templates::common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="card">

            <?php echo Form::open(['route' => 'produits.store']); ?>


            <div class="card-body">

                <div class="row">



            <!-- Libelle Field -->
                <div class="form-group col-sm-6">
                    <?php echo Form::label('libelle', 'Nom du produit:'); ?>

                    <?php echo Form::text('libelle', null, ['class' => 'form-control','required'=>'true']); ?>

                </div>

                <!-- Code Field -->
                <div class="form-group col-sm-6">
                    <?php echo Form::label('code', 'Code:'); ?>

                    <?php echo Form::text('code', null, ['class' => 'form-control','required'=>'true']); ?>

                </div>


                <!-- Qte Init Field -->
                <div class="form-group col-sm-6">
                    <?php echo Form::label('qte_init', 'Quantité Initiale:'); ?>

                    <input type="number" name="qte_init" class="form-control" required>
                </div>


                <!-- Qte Minimal Field -->
            
            
            
            

            <!-- Qte Final Field -->
            

            <!-- Prix Session Field -->
                <div class="form-group col-sm-6">
                    <?php echo Form::label('prix_session', 'Prix Session:'); ?>

                    <input type="number" name="prix_session" class="form-control" required>
                </div>

                <!-- Prix Public Field -->
                <div class="form-group col-sm-6">
                    <?php echo Form::label('prix_public', 'Prix Public:'); ?>

                    <input type="number" name="prix_public" class="form-control" required>
                </div>

                <!-- Date Peremp Field -->
                <div class="form-group col-sm-6">
                    <?php echo Form::label('date_peremp', 'Date péremption:'); ?>

                    <?php echo Form::text('date_peremp', null, ['class' => 'form-control','id'=>'date_peremp','required'=>'true']); ?>

                </div>
    


                <?php $__env->startPush('page_scripts'); ?>
                    <script type="text/javascript">
                        $('#date_peremp').datetimepicker({
                            format: 'YYYY-MM-DD HH:mm:ss',
                            useCurrent: true,
                            sideBySide: true
                        })
                    </script>
            <?php $__env->stopPush(); ?>

            <!-- Qte Sortie Field -->
            

            <!-- lot Id Field -->
                        <div class="form-group col-sm-6">
                            <?php echo Form::label('lot_id', 'Choisir lot:'); ?>

                            <?php echo Form::select('lot_id', $lots, null, ['class' => 'form-control','placeholder' => 'Sélectionnez un lot','required'=>'true']); ?>

                        </div>
                        <!-- categorie Id Field -->
                        <div class="form-group col-sm-6">
                            <?php echo Form::label('categorie_id', 'Choisir catégorie:'); ?>

                            <?php echo Form::select('categorie_id', $categories, null, ['class' => 'form-control','placeholder' => 'Sélectionnez une catégorie','required'=>'true']); ?>

                        </div>
                </div>

            </div>

            <div class="card-footer">
                <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

                <a href="<?php echo e(route('produits.index')); ?>" class="btn btn-default">Cancel</a>
            </div>

            <?php echo Form::close(); ?>


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Hiss24\Downloads\Telegram Desktop\adminlte-generator\resources\views/produits/create.blade.php ENDPATH**/ ?>