<li class="nav-item">
    <a href="<?php echo e(route('categories.index')); ?>"
       class="nav-link <?php echo e(Request::is('categories*') ? 'active' : ''); ?>">
        <p>Categories</p>
    </a>
</li>


<li class="nav-item">
    <a href="<?php echo e(route('lots.index')); ?>"
       class="nav-link <?php echo e(Request::is('lots*') ? 'active' : ''); ?>">
        <p>Lots</p>
    </a>
</li>


<li class="nav-item">
    <a href="<?php echo e(route('produits.index')); ?>"
       class="nav-link <?php echo e(Request::is('produits*') ? 'active' : ''); ?>">
        <p>Produits</p>
    </a>
</li>


<li class="nav-item">
    <a href="<?php echo e(route('acheters.index')); ?>"
       class="nav-link <?php echo e(Request::is('acheters*') ? 'active' : ''); ?>">
        <p>Vendre produit</p>
    </a>
</li>


<li class="nav-item">
    <a href="/sell-prod-list"
       class="nav-link <?php echo e(Request::is('liste*') ? 'active' : ''); ?>">
        <p>Liste des produits vendus</p>
    </a>
</li>
<?php /**PATH C:\Users\Hiss24\Downloads\Telegram Desktop\adminlte-generator\resources\views/layouts/menu.blade.php ENDPATH**/ ?>