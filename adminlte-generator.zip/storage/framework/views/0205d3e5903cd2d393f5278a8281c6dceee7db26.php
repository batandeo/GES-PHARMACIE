




<!-- Libelle Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('libelle', 'Libelle:'); ?>

    <?php echo Form::text('libelle', null, ['class' => 'form-control','required'=>'true']); ?>

</div>
<?php /**PATH C:\laragon\www\adminlte-generator\resources\views/categories/fields.blade.php ENDPATH**/ ?>