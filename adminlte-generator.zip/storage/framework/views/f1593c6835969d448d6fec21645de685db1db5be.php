

<!-- Libelle Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('libelle', 'Nom du produit:'); ?>

    <?php echo Form::text('libelle', null, ['class' => 'form-control','required'=>'true']); ?>

</div>

<!-- Code Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('code', 'Code:'); ?>

    <?php echo Form::text('code', null, ['class' => 'form-control','required'=>'true']); ?>

</div>


<!-- Qte Init Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('qte_init', 'Quantité Initiale:'); ?>

    <input type="number" value="<?php echo e($produit->qte_init); ?>" name="qte_init" class="form-control" required>
</div>


<!-- Qte Minimal Field -->





<!-- Qte Final Field -->


<!-- Prix Session Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('prix_session', 'Prix Session:'); ?>

    <input type="number" value="<?php echo e($produit->prix_session); ?>" name="prix_session" class="form-control" required>
</div>

<!-- Prix Public Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('prix_public', 'Prix Public:'); ?>

    <input type="number" value="<?php echo e($produit->prix_public); ?>" name="prix_public" class="form-control" required>
</div>

<!-- Date Peremp Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('date_peremp', 'Date péremption:'); ?>

    <?php echo Form::text('date_peremp', null, ['class' => 'form-control','id'=>'date_peremp','required'=>'true']); ?>

</div>

<!-- Categorie Id Field -->
<div class="form-group col-6">
    <?php echo Form::label('categorie_id', 'Categories:'); ?>

    <select class="form-control" name="categorie_id">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option value="<?php echo e($cat->id); ?>" <?php if($produit->categorie_id == $cat->id): ?> selected <?php endif; ?>>
                <?php echo e($cat->libelle); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<!-- Categorie Id Field -->
<div class="form-group col-12">
    <?php echo Form::label('lot_id', 'Lots:'); ?>

    <select class="form-control" name="lot_id">
        <?php $__currentLoopData = $lots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option value="<?php echo e($lot->id); ?>" <?php if($produit->lot_id == $lot->id): ?> selected <?php endif; ?>>
                <?php echo e($lot->numero); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<?php $__env->startPush('page_scripts'); ?>
    <script type="text/javascript">
        $('#date_peremp').datetimepicker({
            format: 'YYYY-MM-DD HH:mm:ss',
            useCurrent: true,
            sideBySide: true
        })
    </script>
<?php $__env->stopPush(); ?>

<!-- Qte Sortie Field -->

<?php /**PATH C:\Users\Hiss24\Downloads\Telegram Desktop\adminlte-generator\resources\views/produits/fields.blade.php ENDPATH**/ ?>